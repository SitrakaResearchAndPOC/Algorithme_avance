#include <iostream>
#include <cstdlib>
#include <ctime>

using namespace std;

// Fonction utilitaire pour faire l'exponentiation modulaire
int puissance(int x, unsigned int y, int p)
{
    int res = 1;
    x = x % p;  // Mettre à jour x si x est plus grand ou égal à p
    while (y > 0)
    {
        if (y & 1)
            res = (res * x) % p;
        y = y >> 1;
        x = (x * x) % p;
    }
    return res;
}

// Cette fonction est appelée pour chaque essai. Elle renvoie faux si n est composé
// et renvoie vrai si n est probablement premier.
// d est un nombre impair tel que d*2^r = n-1 pour un certain r >= 1
bool testMiller(int d, int n)
{
    // Toujours utiliser la base 2 pour la simplicité et pour forcer les faux positifs dans les nombres de Carmichael
    int a = 2;  // Base fixe 2 seulement
    // Base non fixe : int a = 2 + rand() % (n - 4);

    // Calculer a^d % n
    int x = puissance(a, d, n);

    if (x == 1 || x == n - 1)
        return true;

    // Continuer à élever x au carré tant que l'une des conditions suivantes n'est pas remplie
    // (i) d n'atteint pas n-1
    // (ii) (x^2) % n n'est pas égal à 1
    // (iii) (x^2) % n n'est pas égal à n-1
    while (d != n - 1)
    {
        x = (x * x) % n;
        d *= 2;

        if (x == 1)
            return false;
        if (x == n - 1)
            return true;
    }

    return false; // Retourner composé
}

// Renvoie faux si n est composé et renvoie vrai si n est probablement premier.
// k est un paramètre d'entrée qui détermine le niveau de précision. Une valeur plus élevée de k indique plus de précision.
bool estPremier(int n, int k)
{
    // Cas particuliers
    if (n <= 1 || n == 4)
        return false;
    if (n <= 3)
        return true;

    // Trouver r tel que n = 2^d * r + 1 pour un certain r >= 1
    int d = n - 1;
    while (d % 2 == 0)
        d /= 2;

    // Exécuter testMiller k fois, en utilisant la base 2 pour générer le pire cas (faux positifs dans les nombres de Carmichael)
    for (int i = 0; i < k; i++)
        if (!testMiller(d, n))
            return false;

    return true;
}

int main()
{
    int k = 4;  // Définir 1 itération pour forcer des faux positifs possibles rapidement

    // Nombres de Carmichael connus pour générer des faux positifs
    int nombresCarmichael[] = {561, 1105, 1729, 2465, 2821, 6601, 8911, 10585, 15841, 29341, 41041};

    cout << "Test des nombres de Carmichael (faux positifs) : \n";
    for (int i = 0; i < 11; i++)
    {
        int n = nombresCarmichael[i];
        cout << n << ": ";
        if (estPremier(n, k))
            cout << "Probablement Premier (Faux Positif)\n";
        else
            cout << "Composite (Correct)\n";
    }

    return 0;
}