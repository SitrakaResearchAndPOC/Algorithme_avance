#include <iostream>
#include <cmath>
#include <vector>

using namespace std;

// Fonction déterministe pour tester la primalité
bool isPrime(int n) {
    if (n <= 1) return false;  // Les nombres <= 1 ne sont pas premiers
    if (n <= 3) return true;   // 2 et 3 sont premiers

    // Si n est divisible par 2 ou 3, ce n'est pas un nombre premier
    if (n % 2 == 0 || n % 3 == 0) return false;

    // Calcul de la racine carrée de n
    int sqrt_n = sqrt(n);

    // Vérification des diviseurs premiers jusqu'à sqrt(n)
    for (int i = 5; i <= sqrt_n; i += 6) {
        if (n % i == 0 || n % (i + 2) == 0) {
            return false; // n est divisible par un autre nombre premier
        }
    }

    return true; // n est un nombre premier
}

int main() {
    // Liste des nombres de Carmichael
    vector<int> carmichaelNumbers = {561, 1105, 1729, 2465, 2821, 6601, 8911, 10585, 15841, 29341, 41041};

    cout << "Test de primalité des nombres de Carmichael (test déterministe) :\n";
    for (int n : carmichaelNumbers) {
        cout << n << ": ";
        if (isPrime(n)) {
            cout << "Premier\n";
        } else {
            cout << "Composé\n";
        }
    }

    return 0;
}