#include <bits/stdc++.h>
using namespace std;

// Fonction pour effectuer l'exponentiation modulaire
long long power(long long x, unsigned int y, long long p) {
    long long res = 1;
    x = x % p;
    while (y > 0) {
        if (y & 1)
            res = (res * x) % p;
        y = y >> 1;
        x = (x * x) % p;
    }
    return res;
}

// Test de Fermat pour vérifier si n est probablement premier avec base 2
bool fermatTest(long long n) {
    if (n <= 1)
        return false; // Nombres inférieurs à 2 ne sont pas premiers
    // Base 2 fixe pour le test de Fermat
    long long base = 2;
    // Fermat Test : Si a^(n-1) % n != 1, alors n n'est pas premier
    if (power(base, n - 1, n) != 1)
        return false;
    return true;
}

// Nombres de Carmichael connus
long long carmichaelNumbers[] = {561, 1105, 1729, 2465, 2821, 6601, 8911, 10585, 15841, 29341, 41041};

int main() {
    // Test de Fermat sur les nombres de Carmichael
    cout << "Test de Fermat avec base 2 sur les nombres de Carmichael :\n";
    for (long long n : carmichaelNumbers) {
        cout << n << ": ";
        if (fermatTest(n))
            cout << "Probablement premier (faux positif possible)\n";
        else
            cout << "Composé (résultat correct)\n";
    }
    return 0;
}